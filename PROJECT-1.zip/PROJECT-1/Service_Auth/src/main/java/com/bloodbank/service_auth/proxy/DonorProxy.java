package com.bloodbank.service_auth.proxy;

import com.bloodbank.service_auth.enums.BloodType;
import com.bloodbank.service_auth.enums.Gender;
import com.bloodbank.service_auth.enums.Role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DonorProxy {
	
	private String username;
	private String password;
	private String fullName;
	private Gender gender;

	private Role role;
	
	private BloodType group;

	private Boolean isActive;
}
