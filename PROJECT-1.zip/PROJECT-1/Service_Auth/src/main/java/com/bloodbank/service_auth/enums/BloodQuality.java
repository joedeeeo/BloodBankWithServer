package com.bloodbank.service_auth.enums;

public enum BloodQuality {
	Moderate,
	High,
	VeryHigh;
}
