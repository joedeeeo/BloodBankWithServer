package com.bloodbank.service_auth.enums;

public enum TransactionType {
	Donation, 
	Consumption;
}
