package com.bloodbank.service_consumer.enums;

public enum Gender {
	MALE,FEMALE;
	
	private String gender;
	
	public String getGender() {
		return gender;
	}
}
 