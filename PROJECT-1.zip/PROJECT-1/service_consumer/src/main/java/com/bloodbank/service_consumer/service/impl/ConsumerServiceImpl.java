package com.bloodbank.service_consumer.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bloodbank.service_consumer.domain.Consumer;
import com.bloodbank.service_consumer.domain.Transaction;
import com.bloodbank.service_consumer.enums.Role;
import com.bloodbank.service_consumer.proxy.ConsumerProxy;
import com.bloodbank.service_consumer.proxy.User;
import com.bloodbank.service_consumer.repository.ConsumerRepo;
import com.bloodbank.service_consumer.service.ConsumerService;
import com.bloodbank.service_consumer.utils.MapperUtils;

@Service
public class ConsumerServiceImpl implements ConsumerService{
	
	@Autowired
	private ConsumerRepo consumerRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired 
	private BCryptPasswordEncoder encoder;

	@Override
	public List<ConsumerProxy> getAllConsumer() {
		// TODO Auto-generated method stub
		return MapperUtils.convertListValue(consumerRepo.findAll(), ConsumerProxy.class);
	}

	@Override
	public ConsumerProxy getConsumerByUsername(String username) {
		// TODO Auto-generated method stub
		Optional<Consumer> byUsername = consumerRepo.findById(username);
		if(byUsername.isPresent()) {
			ConsumerProxy convertValue = MapperUtils.convertValue(byUsername.get(), ConsumerProxy.class);
			return convertValue;
		}
		else {
			throw new RuntimeException("Consumer not found");
		}
	}

	@Override
	public String deleteConsumerByUsername(String username) {
		// TODO Auto-generated method stub
		if(consumerRepo.existsById(username)) {
			consumerRepo.deleteById(username);
			return "Consumer delete successfully";
		}
		return "Consumer not found by this name";
		
	}

	@Override
	public ConsumerProxy saveConsumer(ConsumerProxy consumer) {
		// TODO Auto-generated method stub
//		Boolean isUserAvail = restTemplate.getForObject("http://localhost:8080/bank/is-user-name-available/"+consumer.getUsername(),
//			    Boolean.class
//			);
		Boolean isAvail = restTemplate.getForObject("http://SERVICE-AUTH/auth/isUsernameAvail/"+consumer.getUsername(), Boolean.class);
		if(!isAvail) return null;
		else {
			Consumer con =  MapperUtils.convertValue(consumer, Consumer.class);
			con.setPassword(encoder.encode(con.getPassword()));
			
			User user = new User();
			user.setUsername(con.getUsername());
			user.setPassword(con.getPassword());
			List<Role> roles = new ArrayList<>();
			roles.add(Role.CONSUMER);
			user.setRoles(roles);
			restTemplate.postForObject("http://SERVICE-AUTH/auth/saveUser", user, String.class);
			consumerRepo.save(con);
			
		}
		return null;
	}

	@Override
	public Boolean isConsumerUsernameAvailable(String username) {
		// TODO Auto-generated method stub
		return !consumerRepo.existsById(username);
	}

	@Override
	public String requestBlood(Transaction transaction) {
		// TODO Auto-generated method stub
//		String resp = restTemplate.postForObject("http://localhost:8080/bank/request-blood", transaction,String.class);
		String resp = restTemplate.postForObject("http://SERVICE-BANK/bank/request-blood", transaction,String.class);
		
		return resp;
	}

	@Override
	public List<String> getAllBloodGroups() {
//		String[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-groups", String[].class);
		// TODO Auto-generated method stub
		
		String[] resp = restTemplate.getForObject("http://SERVICE-BANK/bank/get-all-blood-groups", String[].class);
		return List.of(resp);
	}

}
