package com.bloodbank.service_adminserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAdminServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
