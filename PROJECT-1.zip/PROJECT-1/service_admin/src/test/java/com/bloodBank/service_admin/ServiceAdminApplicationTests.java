package com.bloodBank.service_admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
