package com.bloodbank.service_admin.service.impl;import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bloodbank.service_admin.domain.Admin;
import com.bloodbank.service_admin.enums.BloodQuality;
import com.bloodbank.service_admin.enums.BloodType;
import com.bloodbank.service_admin.enums.Role;
import com.bloodbank.service_admin.enums.TransactionType;
import com.bloodbank.service_admin.proxy.AdminProxy;
import com.bloodbank.service_admin.proxy.BloodSampleProxy;
import com.bloodbank.service_admin.proxy.TransactionProxy;
import com.bloodbank.service_admin.proxy.User;
import com.bloodbank.service_admin.repo.AdminRepo;
import com.bloodbank.service_admin.service.AdminService;
import com.bloodbank.service_admin.service.BankService;
import com.bloodbank.service_admin.utils.MapperUtil;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminRepo repo;
	
	@Autowired 
	private RestTemplate restTemplate;
	
	@Autowired
	private BankService bankService;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Override
	public String deleteUser(String username) {
		// TODO Auto-generated method stub
//	   restTemplate.delete("http://localhost:8082/consumer/deleteConsumerByUsername/{username}", username);
		restTemplate.delete("http://SERVICE-CONSUMER/consumer/deleteConsumerByUsername/{username}", username);
		return "user deleted by admin";
	}
 

	@Override
	public List<AdminProxy> getAllAdmin() {
		List<Admin> adminList = repo.findAll();
		return MapperUtil.convertListOfValue(adminList, AdminProxy.class);
	}

	@Override
	public AdminProxy getAdminByUsername(String username) {
		Admin admin = repo.findByUsername(username).orElseThrow(() -> new RuntimeException("Username Not Found Based on given Input"));
		return MapperUtil.convertValue(admin, AdminProxy.class);
	}

	@Override
	public String deleteAdminByUsername(String username) {
		repo.deleteByUsername(username);
		return "Admin has been deleted with username : " + username;
	}

	@Override
	public AdminProxy saveAdmin(AdminProxy adminProxy) {
		Boolean isAvail = restTemplate.getForObject("http://SERVICE-AUTH/auth/isUsernameAvail/"+adminProxy.getUsername(), Boolean.class);
		if(!isAvail) return null;
		Admin admin = MapperUtil.convertValue(adminProxy, Admin.class);
		admin.setPassword(encoder.encode(admin.getPassword()));
		Admin savedAdmin = repo.save(admin);
		adminProxy.setId(savedAdmin.getId());
		User user = new User();
		user.setUsername(admin.getUsername());
		user.setPassword(admin.getPassword());
		List<Role> roles = new ArrayList<>();
		roles.add(Role.ADMIN);
		roles.add(Role.DONOR);
		roles.add(Role.CONSUMER);
		user.setRoles(roles);
		restTemplate.postForObject("http://SERVICE-AUTH/auth/saveUser", user, String.class);
		
		return adminProxy;
	}

	@Override
	public List<String> getAllBloodGroups() {
		// TODO Auto-generated method stub
//		String[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-groups", String[].class);
//		String[] resp = restTemplate.getForObject("http://SERVICE-BANK/bank/get-all-blood-groups", String[].class);
		List<String> resp = bankService.getAllBloodGroups();
		return resp;
	}

	@Override
	public List<BloodSampleProxy> getAllBloodGroupSamples(BloodType bloodGroup) {
		// TODO Auto-generated method stub
//		BloodSampleProxy[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-group-samples/"+bloodGroup.toString(),BloodSampleProxy[].class);
		BloodSampleProxy[] resp = restTemplate.getForObject("http://SERVICE-BANK/bank/get-all-blood-group-samples/"+bloodGroup.toString(),BloodSampleProxy[].class);
		return List.of(resp);
	}

	@Override
	public List<TransactionProxy> getAllBloodGroupTransactions(BloodType bloodGroup) {
		// TODO Auto-generated method stub
//		TransactionProxy[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-group-transactions/"+bloodGroup.toString(), TransactionProxy[].class);
		TransactionProxy[] resp = restTemplate.getForObject("http://service-bank/bank/get-all-blood-group-transactions/"+bloodGroup.toString(), TransactionProxy[].class);
		return List.of(resp);
	}

	@Override
	public List<TransactionProxy> getAllBloodGroupTransactionsAsPerType(BloodType bloodGroup, TransactionType type) {
		// TODO Auto-generated method stub
//		TransactionProxy[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-group-transactions-asper-type/{bloodGroup}/{type}", TransactionProxy[].class,bloodGroup.toString(),type.toString());
		TransactionProxy[] resp = restTemplate.getForObject("http://SERVICE-BANK/bank/get-all-blood-group-transactions-asper-type/{bloodGroup}/{type}", TransactionProxy[].class,bloodGroup.toString(),type.toString());
		return List.of(resp);
	}

	@Override
	public List<BloodSampleProxy> getAllBloodGroupSamplesAsPerQuality(BloodType bloodGroup, BloodQuality quality) {
		// TODO Auto-generated method stub
//		BloodSampleProxy[] resp = restTemplate.getForObject("http://localhost:8080/bank/get-all-blood-group-samples-asper-quality/{bloodGroup}/{quality}",BloodSampleProxy[].class,bloodGroup.toString(),quality.toString());
		BloodSampleProxy[] resp = restTemplate.getForObject("http://SERVICE-BANK/bank/get-all-blood-group-samples-asper-quality/{bloodGroup}/{quality}",BloodSampleProxy[].class,bloodGroup.toString(),quality.toString());
		
		return List.of(resp);
	}

	@Override
	public String addBloodGroup(BloodType newBloodGroup) {
		// TODO Auto-generated method stub
//		String resp = restTemplate.postForObject("http://localhost:8080/bank/add-blood-group/"+newBloodGroup.toString(), null,String.class);
		String resp = restTemplate.postForObject("http://SERVICE-BANK/bank/add-blood-group/"+newBloodGroup.toString(), newBloodGroup,String.class);
		return resp;
	}


	@Override
	public Boolean isAdminExists(String userName) {
		try
		{
			if(repo.findByUsername(userName).get() != null) return true;
			return false;
		}
		catch (Exception e) {
			return false;
		}
		
	}

}
