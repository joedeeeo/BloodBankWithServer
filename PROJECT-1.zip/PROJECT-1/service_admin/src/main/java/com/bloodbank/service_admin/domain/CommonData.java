package com.bloodbank.service_admin.domain;

public class CommonData {
	private String createdDate;
	private String createdBy;
	private String updatedDate;
	private String updatedBy;
}
