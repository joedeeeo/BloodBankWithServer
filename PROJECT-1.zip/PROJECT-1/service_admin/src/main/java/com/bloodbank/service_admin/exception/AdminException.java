package com.bloodbank.service_admin.exception;

public class AdminException {

}
