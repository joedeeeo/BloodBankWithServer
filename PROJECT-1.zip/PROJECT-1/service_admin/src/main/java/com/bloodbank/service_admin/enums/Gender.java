package com.bloodbank.service_admin.enums;

public enum Gender {
	MALE, FEMALE, OTHER;
}
