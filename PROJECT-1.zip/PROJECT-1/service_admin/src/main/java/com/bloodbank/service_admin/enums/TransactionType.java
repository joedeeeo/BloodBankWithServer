package com.bloodbank.service_admin.enums;

public enum TransactionType {
	Donation, 
	Consumption;
}
