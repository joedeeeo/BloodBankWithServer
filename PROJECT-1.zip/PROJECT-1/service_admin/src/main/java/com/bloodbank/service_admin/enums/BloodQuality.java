package com.bloodbank.service_admin.enums;

public enum BloodQuality {
	Moderate,
	High,
	VeryHigh;
}
