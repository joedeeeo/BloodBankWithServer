package com.bloodbank.service_donor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDonorApplicationTests {

	@Test
	void contextLoads() {
	}

}
