package com.bloodbank.service_donor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceDonorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceDonorApplication.class, args);
	}

}
